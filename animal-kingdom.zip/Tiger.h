/*
Pseudocode:

1. **Tiger Class** (inherits from Feline):
   - **Constructors**:
     - **Default Constructor** (`Tiger()`):
       - Calls the default constructor of the `Feline` class using `Feline()`.
       - Sets the `picture` attribute to "Tiger".
       - Prints a message about the tiger's royal status as the "queen of the animal kingdom".

   - **Member Functions**:
     - **makeNoise()** (overridden):
       - Overrides the `makeNoise()` function from the `Feline` class to output the tiger's signature growl ("GROWL!!").

     - **eat()** (overridden):
       - Calls the base `Feline` class's `eat()` function.
       - Adds a tiger-specific message about its royal appetite and preference for the finest meat ("As queen, I deserve the finest of meat.").
*/

#ifndef TIGER_H
#define TIGER_H
#include "Feline.h"
#include <iostream>

// Declares the Tiger class, derived publicly from Feline
class Tiger : public Feline 
{
    public:
        // Inherits all constructors from the Feline class
        using Feline::Feline;
        
        // Default constructor for Tiger class
        Tiger() : Feline() 
        {
            // Sets the picture attribute to "Tiger"
            setPicture("Tiger");
        
            // Outputs a message indicating the tiger's royal status
            std::cout << "Tiger: I am the queen of my animal kingdom!!\n";
        }
    
        // Overrides makeNoise to provide tiger-specific sound
        void makeNoise() override 
        {
            // Outputs the growling noise made by a tiger
            std::cout << "GROWL!!\n";
        }
    
        // Overrides eat to include tiger-specific behavior
        void eat() override 
        {
            // Calls the eat method from the Feline base class
            Feline::eat();
        
            // Outputs a message about the tiger's royal appetite
            std::cout << "As queen, I deserve the finest of meat.\n";
        }
};

#endif  
